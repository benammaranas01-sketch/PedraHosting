<?php
require('../common.php');
header('Content-Type: text/html; charset=UTF-8');
session_start();
if(empty($_SESSION['login_csrf'])){
	$_SESSION['login_csrf']=bin2hex(random_bytes(32));
}
if(!empty($_SESSION['hosting_username']) && empty($_SESSION['2fa_code'])){
	header('Location: home.php');
	exit;
}
$msg='';
$username='';
$pgp_key='';
$tfa=0;
if(!empty($_SESSION['hosting_username'])){
	$tfa = $_SESSION['tfa'];
	$pgp_key = $_SESSION['pgp_key'];
}
if($_SERVER['REQUEST_METHOD']==='POST'){
	if(!empty($_SESSION['hosting_username'])){
		if(!empty($_POST['2fa_code']) && $_POST['2fa_code'] === $_SESSION['2fa_code']){
			unset($_SESSION['2fa_code']);
			unset($_SESSION['pgp_key']);
			unset($_SESSION['tfa']);
			session_write_close();
			header('Location: home.php');
			exit;
		}else{
			$msg.='<p role="alert" style="color:red">'._('Wrong 2FA code').'</p>';
		}
	} else {
		$db = get_db_instance();
		$ok=true;
		if(!isset($_POST['login_csrf']) || !hash_equals($_SESSION['login_csrf'], $_POST['login_csrf'])){
			$msg.='<p role="alert" style="color:red">'._('Error: Invalid request token.').'</p>';
			$ok=false;
		}elseif($error=check_captcha_error()){
			$msg.='<p role="alert" style="color:red">'.$error.'</p>';
			$ok=false;
		}elseif(!isset($_POST['username']) || $_POST['username']===''){
			$msg.='<p role="alert" style="color:red">'._('Error: username may not be empty.').'</p>';
			$ok=false;
		}else{
			$stmt=$db->prepare('SELECT username, password, id, tfa, pgp_key FROM users WHERE username=?;');
			$stmt->execute([$_POST['username']]);
			$tmp=[];
			if(($tmp=$stmt->fetch(PDO::FETCH_ASSOC))===false && preg_match('/^([2-7a-z]{16}).onion$/', $_POST['username'], $match)){
				$stmt=$db->prepare('SELECT users.username, users.password, users.id, users.tfa, users.pgp_key FROM users INNER JOIN onions ON (onions.user_id=users.id) WHERE onions.onion=?;');
				$stmt->execute([$match[1]]);
				$tmp=$stmt->fetch(PDO::FETCH_ASSOC);
			}
			if($tmp){
				$username=$tmp['username'];
				$password=$tmp['password'];
				$tfa=$tmp['tfa'];
				$pgp_key=$tmp['pgp_key'];
				$stmt=$db->prepare('SELECT new_account.approved FROM new_account INNER JOIN users ON (users.id=new_account.user_id) WHERE users.id=?;');
				$stmt->execute([$tmp['id']]);
				if($tmp=$stmt->fetch(PDO::FETCH_NUM)){
					$msg.='<p role="alert" style="color:red">'._('Error: Invalid username or password.').'</p>';
					$ok=false;
				}elseif(!isset($_POST['pass']) || !password_verify($_POST['pass'], $password)){
					$msg.='<p role="alert" style="color:red">'._('Error: Invalid username or password.').'</p>';
					$ok=false;
				}
			}else{
				$msg.='<p role="alert" style="color:red">'._('Error: Invalid username or password.').'</p>';
				$ok=false;
			}
		}
		if($ok){
			session_regenerate_id(true);
			$_SESSION['hosting_username']=$username;
			$_SESSION['csrf_token']=bin2hex(random_bytes(32));
			if($tfa){
				$code = bin2hex(random_bytes(3));
				$_SESSION['2fa_code'] = $code;
				$_SESSION['pgp_key'] = $pgp_key;
				$_SESSION['tfa'] = $tfa;
			} else {
				session_write_close();
				header('Location: home.php');
				exit;
			}
		}
	}
}
print_header(_('Login'));
if($tfa){
	$gpg = gnupg_init();
	gnupg_seterrormode($gpg, GNUPG_ERROR_WARNING);
	gnupg_setarmor($gpg, 1);
	$imported_key = gnupg_import($gpg, $pgp_key);
	if($imported_key){
		$key_info = gnupg_keyinfo($gpg, $imported_key['fingerprint']);
		foreach($key_info as $key){
			if($key['can_encrypt']){
				foreach($key['subkeys'] as $subkey){
					gnupg_addencryptkey($gpg, $subkey['fingerprint']);
				}
			}
		}
		$encrypted = gnupg_encrypt($gpg, _('To login, please enter the following code to confirm ownership of your key:')."\n\n".$_SESSION['2fa_code']."\n");
		echo $msg;
		echo '<p>'._('To login, please decrypt the following PGP encrypted message and confirm the code:').'</p>';
		echo '<textarea readonly="readonly" rows="10" cols="70">'.htmlspecialchars($encrypted, ENT_QUOTES, 'UTF-8').'</textarea>';
		?>
		<form action="login.php" method="post"><input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
		<table border="1">
			<tr><td><input type="text" name="2fa_code"></td><td><button type="submit"><?php echo _('Confirm'); ?></button></td></tr>
		</table></form>
		<p><?php echo _("Don't have the private key at hand?"); ?><a href="logout.php"><?php echo _('Logout'); ?></a></p>
		</body></html>
<?php
		exit;
	}
}
?>
<h1><?php echo _('Hosting - Login'); ?></h1>
<?php
main_menu('login.php');
echo $msg;
?>
<form method="POST" action="login.php"><input type="hidden" name="login_csrf" value="<?php echo $_SESSION['login_csrf']; ?>"><table>
<tr><td><?php echo _('Username'); ?></td><td><input type="text" name="username" value="<?php
if(isset($_POST['username'])){
	echo htmlspecialchars($_POST['username']);
}
?>" required autofocus></td></tr>
<tr><td><?php echo _('Password'); ?></td><td><input type="password" name="pass" required></td></tr>
<?php send_captcha(); ?>
<tr><td colspan="2"><button type="submit"><?php echo _('Login'); ?></button></td></tr>
</table></form>
<p><?php echo _("If you disabled cookies, please re-enable them. You can't log in without!"); ?></p>
</body></html>
